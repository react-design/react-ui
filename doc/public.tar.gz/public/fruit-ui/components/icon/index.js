'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _Icon = require('./Icon');

var _Icon2 = _interopRequireDefault(_Icon);

exports['default'] = {
    Icon: _Icon2['default']
};
module.exports = exports['default'];