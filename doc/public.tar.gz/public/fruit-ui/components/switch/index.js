'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _Switch = require('./Switch');

var _Switch2 = _interopRequireDefault(_Switch);

exports['default'] = {
    Switch: _Switch2['default']
};
module.exports = exports['default'];