'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _Button = require('./Button');

var _Button2 = _interopRequireDefault(_Button);

exports['default'] = {
    Button: _Button2['default']
};
module.exports = exports['default'];