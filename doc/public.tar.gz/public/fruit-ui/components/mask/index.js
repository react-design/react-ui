'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _Mask = require('./Mask');

var _Mask2 = _interopRequireDefault(_Mask);

exports['default'] = {
    Mask: _Mask2['default']
};
module.exports = exports['default'];