'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _Carousel = require('./Carousel');

var _Carousel2 = _interopRequireDefault(_Carousel);

exports['default'] = {
    Carousel: _Carousel2['default']
};
module.exports = exports['default'];